//package com.capgemini;
//
//import com.capgemini.dto.OrderDTO;
//import com.capgemini.dto.PaymentDTO;
//import com.capgemini.feignclient.OrderServiceClient;
//import com.capgemini.model.Payment;
//import com.capgemini.model.PaymentStatus;
//import com.capgemini.repository.PaymentRepository;
//import com.capgemini.service.PaymentServiceImpl;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.time.LocalDate;
//import java.util.List;
//import java.util.UUID;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//class PaymentServiceImplTest {
//
//	@Mock
//	private PaymentRepository paymentRepository;
//
//	@Mock
//	private OrderServiceClient orderServiceClient;
//
//	@InjectMocks
//	private PaymentServiceImpl paymentService;
//
//	private PaymentDTO paymentDTO;
//	private OrderDTO mockOrderDTO;
//	private Payment mockPayment;
//
//	@BeforeEach
//	void setUp() {
//		paymentDTO = new PaymentDTO();
//		paymentDTO.setBillId(1L);
//		paymentDTO.setPaymentDate(LocalDate.now());
//		paymentDTO.setPaymentMode("CREDIT");
//
//		mockOrderDTO = new OrderDTO();
//		mockOrderDTO.setBillId(1L);
//		mockOrderDTO.setBillAmount(500);
//		mockOrderDTO.setBillDueDate(LocalDate.now().minusDays(1)); // Past due date
//
//		mockPayment = new Payment();
//		mockPayment.setPaymentId(100L);
//		mockPayment.setTransactionId(UUID.randomUUID().toString());
//		mockPayment.setBillId(1L);
//		mockPayment.setPaymentDate(LocalDate.now());
//		mockPayment.setPaymentMode("CREDIT");
//		mockPayment.setStatus(PaymentStatus.FAILED);
//		mockPayment.setTotalPaid(500.0);
//	}
//
//	// ✅ 1. Test Successful New Bill Payment
//	@Test
//	void testPayBill_SuccessfulNewPayment() {
//		when(orderServiceClient.getBillById(1L)).thenReturn(mockOrderDTO);
//		when(paymentRepository.findByBillId(1L)).thenReturn(List.of());
//		when(paymentRepository.save(any(Payment.class))).thenAnswer(invocation -> {
//			Payment savedPayment = invocation.getArgument(0);
//			savedPayment.setPaymentId(101L);
//			return savedPayment;
//		});
//
//		PaymentResponse response = paymentService.payBill(paymentDTO);
//
//		assertNotNull(response);
//		assertEquals(PaymentStatus.SUCCESS, response.getStatus());
//		assertEquals(101L, response.getPaymentId());
//		assertNotNull(response.getTransactionId());
//		verify(paymentRepository, times(1)).save(any(Payment.class));
//	}
//
//	// ✅ 2. Test Payment for Bill Already Paid
//	@Test
//	void testPayBill_BillAlreadyPaid() {
//		when(orderServiceClient.getBillById(1L)).thenReturn(mockOrderDTO);
//		when(paymentRepository.findByBillId(1L)).thenReturn(List.of(mockPayment));
//
//		mockPayment.setStatus(PaymentStatus.SUCCESS);
//
//		assertThrows(BillAlreadyPaidException.class, () -> paymentService.payBill(paymentDTO));
//	}
//
//	// ✅ 3. Test Payment for Bill Not Found
//	@Test
//	void testPayBill_BillNotFound() {
//		when(orderServiceClient.getBillById(1L)).thenReturn(null);
//		assertThrows(BillNotFoundException.class, () -> paymentService.payBill(paymentDTO));
//	}
//
//	// ✅ 4. Test Retrying a Failed Payment
//	@Test
//	void testPayBill_RetryFailedPayment() {
//		when(orderServiceClient.getBillById(1L)).thenReturn(mockOrderDTO);
//		when(paymentRepository.findByBillId(1L)).thenReturn(List.of(mockPayment));
//
//		when(paymentRepository.save(any(Payment.class))).thenAnswer(invocation -> {
//			Payment savedPayment = invocation.getArgument(0);
//			savedPayment.setStatus(PaymentStatus.SUCCESS);
//			return savedPayment;
//		});
//
//		PaymentResponse response = paymentService.payBill(paymentDTO);
//
//		assertNotNull(response);
//		assertEquals(PaymentStatus.SUCCESS, response.getStatus());
//		assertNotNull(response.getTransactionId());
//		verify(paymentRepository, times(1)).save(any(Payment.class));
//	}
//
//	// ✅ 5. Test Payment with Late Fee
//	@Test
//	void testPayBill_WithLateFee() {
//		when(orderServiceClient.getBillById(1L)).thenReturn(mockOrderDTO);
//		when(paymentRepository.findByBillId(1L)).thenReturn(List.of());
//		when(paymentRepository.save(any(Payment.class))).thenAnswer(invocation -> {
//			Payment savedPayment = invocation.getArgument(0);
//			savedPayment.setPaymentId(101L);
//			return savedPayment;
//		});
//
//		paymentDTO.setPaymentDate(LocalDate.now().plusDays(2));
//
//		PaymentResponse response = paymentService.payBill(paymentDTO);
//
//		assertEquals(600, response.getTotalAmountPaid()); // Bill Amount (500) + Late Fee (100)
//	}
//
//	// ✅ 6. Test Payment Without Late Fee
//	@Test
//	void testPayBill_WithoutLateFee() {
//		when(orderServiceClient.getBillById(1L)).thenReturn(mockOrderDTO);
//		when(paymentRepository.findByBillId(1L)).thenReturn(List.of());
//		when(paymentRepository.save(any(Payment.class))).thenAnswer(invocation -> {
//			Payment savedPayment = invocation.getArgument(0);
//			savedPayment.setPaymentId(101L);
//			return savedPayment;
//		});
//
//		paymentDTO.setPaymentDate(mockOrderDTO.getBillDueDate());
//
//		PaymentResponse response = paymentService.payBill(paymentDTO);
//
//		assertEquals(500, response.getTotalAmountPaid()); // No late fee
//	}
//
//
//
//
//}
