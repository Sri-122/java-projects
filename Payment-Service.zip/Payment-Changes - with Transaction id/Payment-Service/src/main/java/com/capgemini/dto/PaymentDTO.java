package com.capgemini.dto;

import com.capgemini.model.PaymentStatus;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

public class PaymentDTO {

    private Long paymentId;

    @NotNull(message = "{bill.id.notnull}")
    @Positive(message = "{bill.id.positive}")
    private Long orderId;

//    @NotNull(message = "{payment.date.notnull}")
//    @FutureOrPresent(message = "Payment date cannot be before the bill date")
    private LocalDate paymentDate;

    @NotNull(message = "{payment.mode.notnull}")
    @Pattern(regexp = "CREDIT|DEBIT|WALLET|NETBANKING", message = "Please select from CREDIT, DEBIT, WALLET, NETBANKING")
    private String paymentMode;


    private double totalCost;
    private PaymentStatus status;


    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = LocalDate.now();
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public void setStatus(PaymentStatus status) {
        this.status = PaymentStatus.SUCCESS;
    }



}
