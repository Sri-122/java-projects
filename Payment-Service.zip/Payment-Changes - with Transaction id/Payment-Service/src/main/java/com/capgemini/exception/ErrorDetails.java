package com.capgemini.exception;

public class ErrorDetails {
    private String errorType;
    private String message;
    private int statusCode;

    public ErrorDetails(String errorType, String message, int statusCode) {
        this.errorType = errorType;
        this.message = message;
        this.statusCode = statusCode;
    }

    // Getters and setters

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
}
