package com.capgemini.controller;

import com.capgemini.dto.PaymentDTO;
import com.capgemini.model.PaymentStatus;
import com.capgemini.service.IPaymentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/payment")
@Validated
public class PaymentController {

    @Autowired
    private IPaymentService paymentService;

    // Endpoint to pay the bill
    @PostMapping(value = "/payBill")
    public ResponseEntity<PaymentDTO> payBill(@Valid @RequestBody PaymentDTO paymentDTO) {
        PaymentDTO response = paymentService.payBill(paymentDTO);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/allPayments")
    public ResponseEntity<List<PaymentDTO>> viewAllPayments() {
        List<PaymentDTO> payments = paymentService.viewAllPayments();
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

    @GetMapping(value = "/details/{paymentId}")
    public ResponseEntity<PaymentDTO> getPaymentDetails(@PathVariable Long paymentId) {
        PaymentDTO paymentDTO = paymentService.getPaymentDetails(paymentId);
        return new ResponseEntity<>(paymentDTO, HttpStatus.OK);
    }

    @GetMapping(value = "/status/{status}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByStatus(@PathVariable PaymentStatus status) {
        List<PaymentDTO> payments = paymentService.getPaymentsByStatus(status);
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

}