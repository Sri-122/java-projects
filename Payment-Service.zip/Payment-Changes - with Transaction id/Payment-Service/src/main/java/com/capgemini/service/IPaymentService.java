package com.capgemini.service;

import com.capgemini.dto.PaymentDTO;
import com.capgemini.model.PaymentStatus;

import java.util.List;

public interface IPaymentService {

    PaymentDTO payBill(PaymentDTO paymentDTO);

    //PaymentStatus cancelPayment(Long paymentId) throws NoSuchCustomerException;

    //PaymentStatus updatePayment(Long paymentId, PaymentDTO paymentDTO) throws NoSuchCustomerException;

    PaymentDTO getPaymentDetails(Long paymentId);

    List<PaymentDTO> viewAllPayments();

    List<PaymentDTO> getPaymentsByStatus(PaymentStatus status);

}
