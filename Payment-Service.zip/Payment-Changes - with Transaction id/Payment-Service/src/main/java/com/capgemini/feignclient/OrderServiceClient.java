package com.capgemini.feignclient;

import com.capgemini.dto.OrderDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "orderservice", url = "http://localhost:8991/orders")
public interface OrderServiceClient {
    @GetMapping("/viewOrderById/{orderId}")
    OrderDTO viewOrder(@PathVariable Long orderId);
}