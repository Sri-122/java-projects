package com.capgemini.service;

import com.capgemini.dto.OrderDTO;
import com.capgemini.dto.PaymentDTO;
import com.capgemini.exception.OrderNotFoundException;
import com.capgemini.exception.PaymentNotFoundException;
import com.capgemini.feignclient.OrderServiceClient;
import com.capgemini.model.Payment;
import com.capgemini.model.PaymentStatus;
import com.capgemini.repository.PaymentRepository;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;
import java.util.UUID;

@Service
public class PaymentServiceImpl implements IPaymentService {

    private static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private OrderServiceClient orderServiceClient;

    private final Random random = new Random();

    @Override
    public PaymentDTO payBill(@Valid PaymentDTO paymentDTO) {
        logger.info("Initiating payment for order ID: {}", paymentDTO.getOrderId());

        if (paymentDTO.getOrderId() == null) {
            logger.error("Order ID is null, throwing exception");
            throw new OrderNotFoundException("Order ID cannot be null");
        }

        // Fetch bill details using Feign Client
        OrderDTO fetchedOrderDTO = orderServiceClient.viewOrder(paymentDTO.getOrderId());
        if (fetchedOrderDTO == null) {
            logger.error("Order ID {} not found, throwing exception", paymentDTO.getOrderId());
            throw new OrderNotFoundException("Order ID " + paymentDTO.getOrderId() + " not found");
        }

        Payment payment=convertToEntity(paymentDTO);
        payment.setTotalCost(fetchedOrderDTO.getTotalCost());
        Payment savedPayment = paymentRepository.save(payment);
        logger.info("Payment processed successfully. Payment ID: {}, Order ID: {}, Status: {}",
                savedPayment.getPaymentId(), savedPayment.getOrderId(), savedPayment.getStatus());

        return convertToDTO(payment);
    }

    @Override
    public PaymentDTO getPaymentDetails(Long paymentId) {
        logger.info("Fetching payment details for Payment ID: {}", paymentId);
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> {
                    logger.error("Payment ID {} not found, throwing exception", paymentId);
                    return new PaymentNotFoundException("Payment not found for ID: " + paymentId);
                });

        return convertToDTO(payment);
    }

    @Override
    public List<PaymentDTO> viewAllPayments() {
        logger.info("Fetching all payment records");
        return paymentRepository.findAll().stream().map(this::convertToDTO).toList();
    }

    @Override
    public List<PaymentDTO> getPaymentsByStatus(PaymentStatus status) {
        logger.info("Fetching payments with status: {}", status);
        return paymentRepository.findByStatus(status).stream().map(this::convertToDTO).toList();
    }

    private PaymentDTO convertToDTO(Payment payment) {
        PaymentDTO paymentDTO = new PaymentDTO();
        paymentDTO.setPaymentId(payment.getPaymentId());
        paymentDTO.setPaymentDate(payment.getPaymentDate());
        paymentDTO.setPaymentMode(payment.getPaymentMode());
        paymentDTO.setStatus(payment.getStatus());
        paymentDTO.setOrderId(payment.getOrderId());
        paymentDTO.setTotalCost(payment.getTotalCost());
        return paymentDTO;
    }

    private Payment convertToEntity(PaymentDTO paymentDTO) {
        Payment payment = new Payment();
        payment.setPaymentDate(paymentDTO.getPaymentDate());
        payment.setPaymentMode(paymentDTO.getPaymentMode().toUpperCase());
        payment.setTotalCost(paymentDTO.getTotalCost());
        payment.setStatus(paymentDTO.getStatus());
        payment.setOrderId(paymentDTO.getOrderId());
        payment.setPaymentId(paymentDTO.getPaymentId());

        return payment;
    }
}
