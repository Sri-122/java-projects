package com.capgemini.dto;

public class OrderDTO {
    private Long orderId;

    public Double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }

    private Double totalCost;
    public Long getOrderId(){
        return orderId;
    }
    public void setOrderId(Long orderId){
        this.orderId=orderId;
    }
    @Override
    public String toString(){
        return "OrderDTO{" +
                "orderId=" + orderId +
                "totalcost=" +totalCost +
                '}';
    }
}
