package com.project1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
//class OrderserviceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.project1.client.CartServiceClient;
import com.project1.dto.OrderDTO;
import com.project1.entity.Order;
import com.project1.exception.OrderNotFoundException;
import com.project1.repository.IOrderRepository;
import com.project1.service.IOrderServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class IOrderServiceImplTest {

	@Mock
	private IOrderRepository orderRepository;

	@Mock
	private CartServiceClient cartServiceClient;

	@InjectMocks
	private IOrderServiceImpl orderService;

	private Order order;
	private OrderDTO orderDTO;

	@BeforeEach
	void setUp() {
		order = new Order();
		order.setOrderId(1L);
		order.setUserId(101L);
		order.setOrderStatus("PENDING");
		order.setOrderDate(LocalDate.now());
		order.setAddress("123 Street, City");
		order.setTotalCost(50.0);

		orderDTO = new OrderDTO();
		orderDTO.setOrderId(1L);
		orderDTO.setUserId(101L);
		orderDTO.setOrderStatus("PENDING");
		orderDTO.setOrderDate(LocalDate.now());
		orderDTO.setAddress("123 Street, City");
	}


	@Test
	void testUpdateOrder_NotFound() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.empty());

		assertThrows(OrderNotFoundException.class, () -> orderService.updateOrder(order.getOrderId(), orderDTO));
	}


	@Test
	void testViewOrder_NotFound() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.empty());

		assertThrows(OrderNotFoundException.class, () -> orderService.viewOrder(order.getOrderId()));
	}



	@Test
	void testViewOrdersByUserId_Empty() {
		when(orderRepository.findByUserId(999L)).thenReturn(List.of());

		List<OrderDTO> result = orderService.viewOrdersByUserId(999L);

		assertTrue(result.isEmpty());
	}


	@Test
	void testViewOrdersByAddress_Empty() {
		when(orderRepository.findByAddress("Unknown")).thenReturn(List.of());

		List<OrderDTO> result = orderService.viewOrdersByAddress("Unknown");

		assertTrue(result.isEmpty());
	}


	@Test
	void testViewOrdersByDate_Empty() {
		when(orderRepository.findByOrderDate(LocalDate.of(2020, 1, 1))).thenReturn(List.of());

		List<OrderDTO> result = orderService.viewOrdersByDate(LocalDate.of(2020, 1, 1));

		assertTrue(result.isEmpty());
	}

	@Test
	void testRemoveOrder_Success() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.of(order));
		doNothing().when(orderRepository).delete(order);

		Order deletedOrder = orderService.removeOrder(order.getOrderId());
		assertNotNull(deletedOrder);
	}

	@Test
	void testRemoveOrder_NotFound() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.empty());

		assertThrows(OrderNotFoundException.class, () -> orderService.removeOrder(order.getOrderId()));
	}


	@Test
	void testViewOrder_InvalidId() {
		when(orderRepository.findById(999L)).thenReturn(Optional.empty());

		assertThrows(OrderNotFoundException.class, () -> orderService.viewOrder(999L));
	}

	@Test
	void testRemoveOrder_InvalidId() {
		when(orderRepository.findById(999L)).thenReturn(Optional.empty());

		assertThrows(OrderNotFoundException.class, () -> orderService.removeOrder(999L));
	}
}
