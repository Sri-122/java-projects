package com.project1.client;
import com.project1.dto.Cart;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="cartModule")
public interface CartServiceClient {

    @GetMapping("/cart/showAllCarts/{cartId}")
    Cart showCartById(@PathVariable int cartId);

}
