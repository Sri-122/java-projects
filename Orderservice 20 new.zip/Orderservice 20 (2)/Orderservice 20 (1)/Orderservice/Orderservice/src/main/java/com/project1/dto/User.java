package com.project1.dto;
import java.util.Set;

public class User {

    public User(Long userId, String username, String password, Long userPhone, String email,
                Set<String> roles) {
        super();
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.userPhone = userPhone;
        this.email = email;
        this.roles = roles;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(Long userPhone) {
        this.userPhone = userPhone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Set<String> getRoles() {
        return roles;
    }

    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }

    private Long userId;

    private String username;

    private String password;

    private Long userPhone;

    private String email;

    private Set<String> roles;

    public User() {
        super();

    }
}





