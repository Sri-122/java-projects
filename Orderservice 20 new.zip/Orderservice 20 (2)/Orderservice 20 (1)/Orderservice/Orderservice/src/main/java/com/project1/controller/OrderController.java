package com.project1.controller;
import com.project1.dto.OrderDTO;
import com.project1.entity.Order;
import com.project1.exception.OrderAlreadyExistsException;
import com.project1.exception.OrderNotFoundException;
import com.project1.service.IOrderServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;


@RestController
@RequestMapping("/orders")
public class OrderController {

    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private IOrderServiceImpl orderService;

    @PostMapping("/addOrder")
    public ResponseEntity<OrderDTO> addOrder(@RequestBody OrderDTO orderDTO) {
        logger.info("Received request to add an order: {}", orderDTO);

        try {
            OrderDTO createdOrder = orderService.addOrder(orderDTO);
            logger.info("Order created successfully with ID: {}", createdOrder.getOrderId());
            return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
        } catch (OrderAlreadyExistsException e) {
            logger.error("Failed to create order. Order already exists: {}", orderDTO.getOrderId());
            return new ResponseEntity<>(null, HttpStatus.CONFLICT);
        }
    }

    @PutMapping("/updateOrder/{orderId}")
    public ResponseEntity<OrderDTO> updateOrder(@PathVariable Long orderId, @RequestBody OrderDTO orderDTO) {
        logger.info("Received request to update order with ID: {}", orderId);
        try {
            OrderDTO updatedOrder = orderService.updateOrder(orderId, orderDTO);
            logger.info("Order updated successfully: {}", updatedOrder);
            return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
        } catch (OrderNotFoundException e) {
            logger.error("Order not found for update with ID: {}", orderId);
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/viewOrderById/{orderId}")
    public ResponseEntity<OrderDTO> viewOrder(@PathVariable Long orderId) {
        logger.info("Fetching order with ID: {}", orderId);
        try {
            OrderDTO order = orderService.viewOrder(orderId);
            logger.info("Order fetched successfully: {}", order);
            return new ResponseEntity<>(order, HttpStatus.OK);
        } catch (OrderNotFoundException e) {
            logger.error("Order not found with ID: {}", orderId);
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/viewOrdersByAddress/{address}")
    public ResponseEntity<List<OrderDTO>> viewOrdersByAddress(@PathVariable String address) {
        logger.info("Fetching orders for address: {}", address);
        List<OrderDTO> orders = orderService.viewOrdersByAddress(address);
        logger.info("Total orders found: {}", orders.size());
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    @GetMapping("/date/{orderDate}")
    public ResponseEntity<List<OrderDTO>> viewOrdersByDate(@PathVariable String orderDate) {
        logger.info("Fetching orders for date: {}", orderDate);
        LocalDate parsedDate = LocalDate.parse(orderDate);
        List<OrderDTO> orders = orderService.viewOrdersByDate(parsedDate);
        logger.info("Total orders found for date {}: {}", orderDate, orders.size());
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    @DeleteMapping("/remove/{orderId}")
    public ResponseEntity<Order> removeOrder(@PathVariable Long orderId) {
        logger.info("Received request to remove order with ID: {}", orderId);
        try {
            Order removedOrder = orderService.removeOrder(orderId);
            logger.info("Order removed successfully: {}", removedOrder);
            return new ResponseEntity<>(removedOrder, HttpStatus.NO_CONTENT);
        } catch (OrderNotFoundException e) {
            logger.error("Order not found for deletion with ID: {}", orderId);
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

        @GetMapping("/all")
        public ResponseEntity<List<OrderDTO>> getAllOrders() {
            logger.info("Received request to fetch all orders");
            List<OrderDTO> orders = orderService.getAllOrders();

            if (orders.isEmpty()) {
                logger.warn("No orders found in database");
                return ResponseEntity.noContent().build();  // Returns 204 if no orders exist
            }

            return new ResponseEntity<>(orders,HttpStatus.OK);
        }


    }
