package com.sweetmart.controller;

import com.sweetmart.dto.CartDTO;
import com.sweetmart.model.Cart;
import com.sweetmart.service.ICartService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Arrays;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.fasterxml.jackson.databind.ObjectMapper;


@ExtendWith(MockitoExtension.class)
class CartControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ICartService cartService;

    @InjectMocks
    private CartController cartController;

    private CartDTO cartDTO;
    private Cart cart;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(cartController).build();

        cartDTO = new CartDTO();
        cartDTO.setCartId(1);
        cartDTO.setUserId(101);
        cartDTO.setProductId(Arrays.asList(201, 202));
        cartDTO.setProductCount(2);
        cartDTO.setTotal(500.0);

        cart = new Cart();
        cart.setCartId(1);
        cart.setUserId(101);
        cart.setProductId(Arrays.asList(201, 202));
        cart.setProductCount(2);
        cart.setTotal(500.0);
    }

    @Test
    void testAddCart_Success() throws Exception {
        when(cartService.addCart(any(CartDTO.class))).thenReturn(cartDTO);

        mockMvc.perform(post("/cart/addCart")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(cartDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.cartId").value(1))
                .andExpect(jsonPath("$.userId").value(101));
    }



    @Test
    void testUpdateCart_Success() throws Exception {
        when(cartService.showCartById(1)).thenReturn(cart);
        when(cartService.updateCart(any(CartDTO.class))).thenReturn(cartDTO);

        mockMvc.perform(put("/cart/updateCart/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(cartDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cartId").value(1));
    }

    @Test
    void testCancelCart_Success() throws Exception {
        when(cartService.cancelCart(1)).thenReturn("Cart deleted successfully");

        mockMvc.perform(delete("/cart/cancelCart/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Cart deleted successfully"));
    }



    @Test
    void testShowAllCarts_Success() throws Exception {
        List<Cart> carts = Arrays.asList(cart);
        when(cartService.showAllCarts()).thenReturn(carts);

        mockMvc.perform(get("/cart/showAllCarts"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testShowAllCarts_EmptyList() throws Exception {
        when(cartService.showAllCarts()).thenReturn(Arrays.asList());

        mockMvc.perform(get("/cart/showAllCarts"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(0));
    }

    @Test
    void testShowCartById_Success() throws Exception {
        when(cartService.showCartById(1)).thenReturn(cart);

        mockMvc.perform(get("/cart/showAllCarts/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cartId").value(1));
    }

    @Test
    void testCancelCart_InvalidId() throws Exception {
        mockMvc.perform(delete("/cart/cancelCart/abc")) // Invalid ID format
                .andExpect(status().isBadRequest());
    }

    @Test
    void testShowCartById_InvalidId() throws Exception {
        mockMvc.perform(get("/cart/showAllCarts/abc")) // Invalid ID format
                .andExpect(status().isBadRequest());
    }
}
