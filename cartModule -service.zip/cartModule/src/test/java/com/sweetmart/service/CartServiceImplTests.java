package com.sweetmart.service;

import com.sweetmart.client.ProductServiceClient;
import com.sweetmart.client.UserServiceClient;
import com.sweetmart.dto.CartDTO;
import com.sweetmart.dto.Product;
import com.sweetmart.dto.User;
import com.sweetmart.exceptions.CartNotFoundException;
import com.sweetmart.exceptions.UserNotFoundException;
import com.sweetmart.model.Cart;
import com.sweetmart.repo.ICartRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CartServiceImplTest {

    @Mock
    private ICartRepository cartRepo;

    @Mock
    private ProductServiceClient productServiceClient;

    @Mock
    private UserServiceClient userServiceClient;

    @InjectMocks
    private CartServiceImpl cartService;

    private Cart cart;
    private CartDTO cartDTO;
    private User user;
    private Product product;

    @BeforeEach
    void setUp() {
        cart = new Cart();
        cart.setCartId(1);
        cart.setUserId(101);
        cart.setProductId(Arrays.asList(201, 202));
        cart.setProductCount(2);
        cart.setTotal(500.0);

        cartDTO = new CartDTO();
        cartDTO.setCartId(1);
        cartDTO.setUserId(101);
        cartDTO.setProductId(Arrays.asList(201, 202));
        cartDTO.setProductCount(2);
        cartDTO.setTotal(500.0);

        user = new User();
        user.setUserId(1L);

        product = new Product();
        product.setProductId(201);
        product.setPrice(100.0);
    }



    @Test
    void testUpdateCart_Success() throws CartNotFoundException {
        // Mocking repository to return an existing cart
        when(cartRepo.findById(1)).thenReturn(Optional.of(cart));

        // Mock product service calls
        when(productServiceClient.getProductById(201)).thenReturn(product);
        when(productServiceClient.getProductById(202)).thenReturn(product);

        // Mock cart save behavior
        when(cartRepo.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CartDTO updatedCartDTO = cartService.updateCart(cartDTO);

        assertNotNull(updatedCartDTO);
        assertEquals(cartDTO.getCartId(), updatedCartDTO.getCartId());
        assertEquals(cartDTO.getUserId(), updatedCartDTO.getUserId());

        // Verify interactions
        verify(cartRepo, times(1)).findById(1);
        verify(cartRepo, times(1)).save(any(Cart.class));
        verify(productServiceClient, times(2)).getProductById(anyInt()); // Ensuring product lookup happens
    }


    @Test
    void testUpdateCart_CartNotFound() {
        when(cartRepo.findById(1)).thenReturn(Optional.empty());

        Exception exception = assertThrows(CartNotFoundException.class, () -> {
            cartService.updateCart(cartDTO);
        });

        assertTrue(exception.getMessage().contains("Cart not found with id"));
    }

    @Test
    void testCancelCart_Success() throws CartNotFoundException {
        when(cartRepo.findById(1)).thenReturn(Optional.of(cart));

        String result = cartService.cancelCart(1);

        assertEquals("Cart deleted successfully", result);
        verify(cartRepo, times(1)).delete(cart);
    }

    @Test
    void testCancelCart_CartNotFound() {
        when(cartRepo.findById(1)).thenReturn(Optional.empty());

        Exception exception = assertThrows(CartNotFoundException.class, () -> {
            cartService.cancelCart(1);
        });

        assertTrue(exception.getMessage().contains("Cart not found"));
    }

    @Test
    void testShowAllCarts() {
        List<Cart> carts = Arrays.asList(cart);
        when(cartRepo.findAll()).thenReturn(carts);

        List<Cart> result = cartService.showAllCarts();

        assertEquals(1, result.size());
        assertEquals(101, result.get(0).getUserId());
    }

    @Test
    void testShowCartById_Success() throws CartNotFoundException {
        when(cartRepo.findById(1)).thenReturn(Optional.of(cart));

        Cart result = cartService.showCartById(1);

        assertNotNull(result);
        assertEquals(101, result.getUserId());
    }

    @Test
    void testShowCartById_CartNotFound() {
        when(cartRepo.findById(1)).thenReturn(Optional.empty());

        Exception exception = assertThrows(CartNotFoundException.class, () -> {
            cartService.showCartById(1);
        });

        assertTrue(exception.getMessage().contains("Cart not found"));
    }

    @Test
    void testCalculateTotalCost_Success() {
        when(productServiceClient.getProductById(201)).thenReturn(product);
        when(productServiceClient.getProductById(202)).thenReturn(product);

        double totalCost = cartService.calculateTotalCost(Arrays.asList(201, 202), 2);

        assertEquals(400.0, totalCost);
    }


    @Test
    void testConvertToDTO() {
        CartDTO dto = cartService.convertToDTO(cart);

        assertNotNull(dto);
        assertEquals(1, dto.getCartId());
        assertEquals(101, dto.getUserId());
    }


    @Test
    void testEmptyCartList() {
        when(cartRepo.findAll()).thenReturn(Arrays.asList());

        List<Cart> result = cartService.showAllCarts();

        assertTrue(result.isEmpty());
    }

    @Test
    void testDeleteNonExistingCart() {
        when(cartRepo.findById(999)).thenReturn(Optional.empty());

        Exception exception = assertThrows(CartNotFoundException.class, () -> {
            cartService.cancelCart(999);
        });

        assertTrue(exception.getMessage().contains("Cart not found"));
    }
}

