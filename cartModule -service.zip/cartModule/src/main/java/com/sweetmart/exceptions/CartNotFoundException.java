package com.sweetmart.exceptions;

public class CartNotFoundException extends Exception{
    public CartNotFoundException(String message){
        super(message);
    }
    public CartNotFoundException(){

    }

}