package com.sweetmart.service;

import com.sweetmart.client.ProductServiceClient;
import com.sweetmart.client.UserServiceClient;
import com.sweetmart.dto.CartDTO;
import com.sweetmart.dto.Product;
import com.sweetmart.dto.User;
import com.sweetmart.exceptions.CartNotFoundException;
import com.sweetmart.exceptions.UserNotFoundException;
import com.sweetmart.model.Cart;
import com.sweetmart.repo.ICartRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartServiceImpl implements ICartService {

    private static final Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);

    @Autowired
    private ICartRepository cartRepo;

    @Autowired
    private ProductServiceClient productServiceClient;
    @Autowired
    private UserServiceClient userServiceClient;

    @Override
    public CartDTO addCart(CartDTO cartDTO) throws UserNotFoundException {
        logger.info("Adding a new cart for user: {}", cartDTO.getUserId());
        Cart cart = convertToEntity(cartDTO);
        cart.setTotal(calculateTotalCost(cart.getProductId(), cart.getProductCount()));
        cart.setUserId(cartDTO.getUserId());

        // Save the cart
        Cart savedCart = cartRepo.save(cart);
        logger.info("Cart saved with ID: {}", savedCart.getCartId());
        User user = userServiceClient.viewUser((long) cartDTO.getUserId());  // Assuming userId is an integer in BookingDTO
        if (user == null) {
            logger.error("User not found with ID: {}", cartDTO.getUserId());
            throw new UserNotFoundException("User not found with ID: " + cartDTO.getUserId());

        }
        return convertToDTO(savedCart);
    }

    @Override
    public CartDTO updateCart(CartDTO cartDTO) throws CartNotFoundException {
        logger.info("Updating cart with ID: {}", cartDTO.getCartId());

        int cartId = cartDTO.getCartId();
        Cart oldCart = cartRepo.findById(cartId).orElseThrow(() -> {
            logger.error("Cart not found with ID: {}", cartId);
            return new CartNotFoundException("Cart not found with id: " + cartId);
        });

        // Update the cart
        Cart updatedCart = convertToEntity(cartDTO);
        updatedCart.setUserId(cartDTO.getUserId());
        updatedCart.setTotal(calculateTotalCost(cartDTO.getProductId(), cartDTO.getProductCount()));
        cartRepo.save(updatedCart);

        logger.info("Cart with ID: {} updated successfully", cartId);
        return convertToDTO(updatedCart);
    }

    @Override
    public String cancelCart(Integer cartId) throws CartNotFoundException {
        logger.info("Canceling cart with ID: {}", cartId);
        Cart cart = cartRepo.findById(cartId).orElseThrow(() -> {
            logger.error("Cart not found with ID: {}", cartId);
            return new CartNotFoundException("Cart not found");
        });

        // Delete the cart
        cartRepo.delete(cart);
        logger.info("Cart with ID: {} deleted successfully", cartId);
        return "Cart deleted successfully";
    }

    @Override
    public List<Cart> showAllCarts() {
        logger.info("Fetching all carts");
        List<Cart> carts = cartRepo.findAll();
        logger.info("Total carts fetched: {}", carts.size());
        return carts;
    }

    @Override
    public Cart showCartById(Integer cartId) throws CartNotFoundException {
        logger.info("Fetching cart with ID: {}", cartId);
        Cart cart = cartRepo.findById(cartId).orElseThrow(() -> {
            logger.error("Cart not found with ID: {}", cartId);
            return new CartNotFoundException("Cart not found");
        });
        return cart;
    }

    public Double calculateTotalCost(List<Integer> productId, int productCount) {
        logger.info("Calculating total cost for products: {}", productId);
        double totalCost = 0;
        for (Integer id : productId) {
            Product product = productServiceClient.getProductById(id);
            totalCost += product.getPrice() * productCount;
        }
        logger.info("Total cost calculated: {}", totalCost);
        return totalCost;
    }

    public CartDTO convertToDTO(Cart cart) {
        logger.debug("Converting Cart entity to DTO for cartId: {}", cart.getCartId());
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCartId(cart.getCartId());
        cartDTO.setProductId(cart.getProductId());
        cartDTO.setTotal(cart.getTotal());
        cartDTO.setProductCount(cart.getProductCount());
        cartDTO.setUserId(cart.getUserId());
        return cartDTO;
    }

    public Cart convertToEntity(CartDTO cartDTO) {
        logger.debug("Converting CartDTO to entity for cartId: {}", cartDTO.getCartId());
        Cart cart = new Cart();
        cart.setCartId(cartDTO.getCartId());
        cart.setProductId(cartDTO.getProductId());
        cart.setProductCount(cartDTO.getProductCount());
        cart.setTotal(cartDTO.getTotal());
        return cart;
    }
}
