package com.sweetmart.controller;

import com.sweetmart.dto.CartDTO;
import com.sweetmart.exceptions.CartNotFoundException;
import com.sweetmart.exceptions.UserNotFoundException;
import com.sweetmart.model.Cart;
import com.sweetmart.service.ICartService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartController {

    private static final Logger logger = LoggerFactory.getLogger(CartController.class);

    @Autowired
    private ICartService cartService;

    @PostMapping("/addCart")
    public ResponseEntity<CartDTO> addCart(@Valid @RequestBody CartDTO cartDTO) throws UserNotFoundException {
        logger.info("Adding new cart: {}", cartDTO);
        CartDTO createdCart = cartService.addCart(cartDTO);
        //createdCart.setCartId(cartDTO.getCartId());
        createdCart.setUserId(cartDTO.getUserId());
        logger.info("Cart added successfully with ID: {}", createdCart.getCartId());
        return new ResponseEntity<>(createdCart, HttpStatus.CREATED);
    }

    @PutMapping("/updateCart/{cartId}")
    public ResponseEntity<CartDTO> updateCart(@RequestBody CartDTO cart, @PathVariable int cartId) throws CartNotFoundException {
        logger.info("Updating cart with ID: {}", cartId);
        Cart existingCart = cartService.showCartById(cartId);
        if (existingCart == null) {
            logger.error("Cart with ID: {} not found", cartId);
            throw new CartNotFoundException();
        }
        cart.setCartId(cartId);
        CartDTO updatedCart = cartService.updateCart(cart);
        logger.info("Cart updated successfully: {}", updatedCart);
        return new ResponseEntity<>(updatedCart, HttpStatus.OK);
    }

    @DeleteMapping("/cancelCart/{cartId}")
    public ResponseEntity<String> cancelCart(@PathVariable int cartId) throws CartNotFoundException {
        logger.info("Cancelling cart with ID: {}", cartId);
        String canceledCart = cartService.cancelCart(cartId);
        logger.info("Cart cancelled successfully: {}", cartId);
        return new ResponseEntity<>(canceledCart, HttpStatus.OK);
    }

    @GetMapping("/showAllCarts")
    public ResponseEntity<List<Cart>> showAllCarts() {
        logger.info("Fetching all carts");
        List<Cart> allCarts = cartService.showAllCarts();
        logger.info("Total carts found: {}", allCarts.size());
        return new ResponseEntity<>(allCarts, HttpStatus.OK);
    }

    @GetMapping("/showAllCarts/{cartId}")
    public ResponseEntity<Cart> showCartById(@PathVariable int cartId) throws CartNotFoundException {
        logger.info("Fetching cart with ID: {}", cartId);
        Cart cart = cartService.showCartById(cartId);
        logger.info("Cart found: {}", cart);
        return new ResponseEntity<>(cart, HttpStatus.OK);
    }
}
