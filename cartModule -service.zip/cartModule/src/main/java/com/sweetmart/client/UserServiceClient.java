package com.sweetmart.client;

import com.sweetmart.dto.User;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="user-service")
public interface UserServiceClient {
    @GetMapping ("/users/view/{id}")
    User viewUser(@PathVariable  Long id);

}
