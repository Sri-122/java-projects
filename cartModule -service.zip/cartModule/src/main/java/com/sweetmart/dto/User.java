package com.sweetmart.dto;

import java.util.Set;

public class User {
        private Long userId;
        private String username;
        private String password;
        private String passwordConfirm;
        private Set<String> role;
        public User(Long userId, String username, String password, String passwordConfirm, Set<String> role) {
            this.userId = userId;
            this.username = username;
            this.password = password;
            this.passwordConfirm = passwordConfirm;
            this.role = role;
        }
        public User() {
        }
        public Long getUserId() {
            return userId;
        }
        public void setUserId(Long userId) {
            this.userId = userId;
        }
        public String getUsername() {
            return username;
        }
        public void setUsername(String username) {
            this.username = username;
        }
        public String getPassword() {
            return password;
        }
        public void setPassword(String password) {
            this.password = password;
        }
        public String getPasswordConfirm() {
            return passwordConfirm;
        }
        public void setPasswordConfirm(String passwordConfirm) {
            this.passwordConfirm = passwordConfirm;
        }
        public Set<String> getRole() {
            return role;
        }
        public void setRole(Set<String> role) {
            this.role = role;
        }
}


