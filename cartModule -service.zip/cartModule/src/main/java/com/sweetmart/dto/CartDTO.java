package com.sweetmart.dto;
import java.util.List;
import java.util.Map;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

public class CartDTO {

    private int cartId;
    private int userId;
    @NotNull(message="{productCount.null}")
    @Positive(message="{productCount.negative}")
    private Integer productCount;
    private Double total;
    @NotNull(message = "{productId.null}")
    private List<Integer> productId;

    public CartDTO() {
        super();
    }

    public CartDTO(int cartId, int userId, Integer productCount, Double total, List<Integer> productId) {
        this.cartId = cartId;
        this.userId = userId;
        this.productCount = productCount;
        this.total = total;
        this.productId = productId;
    }

    public int getCartId() {
        return cartId;
    }
    public void setCartId(int cartId) {
        this.cartId = cartId;
    }
    public Integer getProductCount() {
        return productCount;
    }
    public void setProductCount(Integer productCount) {
        this.productCount = productCount;
    }
    public Double getTotal() {
        return total;
    }
    public void setTotal(Double total) {
        this.total = total;
    }
    public List<Integer> getProductId() {
        return productId;
    }
    public void setProductId(List<Integer> productId) {
        this.productId = productId;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }

}
