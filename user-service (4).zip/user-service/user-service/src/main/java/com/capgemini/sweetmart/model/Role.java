package com.capgemini.sweetmart.model;

public enum Role {
    Admin,Customer
}
