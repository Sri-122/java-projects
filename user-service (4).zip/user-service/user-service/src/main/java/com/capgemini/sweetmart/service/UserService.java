package com.capgemini.sweetmart.service;

import com.capgemini.sweetmart.dto.LoginRequest;
import com.capgemini.sweetmart.dto.UserDto;
import com.capgemini.sweetmart.exceptions.UserNotFoundException;

import java.util.List;

    public interface UserService {
        UserDto register(UserDto userDto);
        UserDto validateUser(UserDto userDto) throws UserNotFoundException;
        UserDto updateUser(UserDto userDto) throws UserNotFoundException;
        UserDto updateUserPassword(Long userId, String newPassword) throws UserNotFoundException;
//        UserDto removeUser(Long userId) throws UserNotFoundException;
        String deleteUser(Long userId) throws UserNotFoundException;
        List<UserDto> viewUser();
        UserDto viewUser(Long userId) throws UserNotFoundException;
        String login(LoginRequest loginRequest);

    }


