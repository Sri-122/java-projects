package com.capgemini.sweetmart.service;

import com.capgemini.sweetmart.dto.LoginRequest;
import com.capgemini.sweetmart.dto.UserDto;
import com.capgemini.sweetmart.exceptions.UserNotFoundException;
import com.capgemini.sweetmart.jwt.JwtUtil;
import com.capgemini.sweetmart.model.User;
import com.capgemini.sweetmart.repository.IUserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserDto register(UserDto userDto) {
        logger.info("Registering user with username: {}", userDto.getUsername());
        User user = mapToEntity(userDto);
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        User newUser = userRepository.save(user);
        logger.info("User registered successfully with ID: {}", newUser.getUserId());
        return mapToDto(newUser);
    }

    @Override
    public UserDto validateUser(UserDto userDto) throws UserNotFoundException {
        logger.info("Validating user with username: {}", userDto.getUsername());
        Optional<User> foundUser = userRepository.findById(userDto.getUserId());
        if (foundUser.isPresent() && passwordEncoder.matches(userDto.getPassword(), foundUser.get().getPassword())) {
            logger.info("User validated successfully with username: {}", userDto.getUsername());
            return mapToDto(foundUser.get());
        }
        logger.error("Invalid user credentials for username: {}", userDto.getUsername());
        throw new UserNotFoundException("Invalid user credentials");
    }

    @Override
    public UserDto updateUser(UserDto userDto) throws UserNotFoundException {
        logger.info("Updating user with ID: {}", userDto.getUserId());
        User existingUser = userRepository.findById(userDto.getUserId())
                .orElseThrow(() -> new UserNotFoundException("User not found"));

        if (userDto.getUsername() != null) existingUser.setUsername(userDto.getUsername());
        if (userDto.getPassword() != null) existingUser.setPassword(passwordEncoder.encode(userDto.getPassword()));
        if (userDto.getUserPhone() != null) existingUser.setUserPhone(userDto.getUserPhone());
        if (userDto.getEmail() != null) existingUser.setEmail(userDto.getEmail());
        if (userDto.getRoles() != null) existingUser.setRoles(userDto.getRoles());

        User updatedUser = userRepository.save(existingUser);
        logger.info("User with ID: {} updated successfully", updatedUser.getUserId());
        return mapToDto(updatedUser);
    }

    @Override
    public UserDto updateUserPassword(Long userId, String newPassword) throws UserNotFoundException {
        logger.info("Updating password for user with ID: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
        user.setPassword(passwordEncoder.encode(newPassword));
        User updatedUser = userRepository.save(user);
        logger.info("Password updated for user with ID: {}", userId);
        return mapToDto(updatedUser);
    }

    @Override
    public UserDto viewUser(Long userId) throws UserNotFoundException {
        logger.info("Fetching user with ID: {}", userId);
        return userRepository.findById(userId)
                .map(this::mapToDto)
                .orElseThrow(() -> {
                    logger.error("User not found with ID: {}", userId);
                    return new UserNotFoundException("User not found");
                });
    }

    @Override
    public List<UserDto> viewUser() {
        logger.info("Fetching all users");
        return userRepository.findAll().stream().map(this::mapToDto).collect(Collectors.toList());
    }

    @Override
    public String deleteUser(Long userId) throws UserNotFoundException {
        logger.info("Attempting to delete user with ID: {}", userId);
        if (!userRepository.existsById(userId)) {
            logger.error("User not found with ID: {}", userId);
            throw new UserNotFoundException("User not found");
        }
        userRepository.deleteById(userId);
        logger.info("User with ID: {} deleted successfully", userId);
        return "User deleted successfully";
    }

    @Override
    public String login(LoginRequest loginRequest) {
        logger.info("Attempting to login user with username: {}", loginRequest.username());
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                loginRequest.username(), loginRequest.password()));
        String token = jwtUtil.generateToken(loginRequest.username());
        logger.info("Login successful for user with username: {}", loginRequest.username());
        return token;
    }

    private UserDto mapToDto(User user) {
        return new UserDto(user.getUserId(), user.getUsername(),
                user.getPassword(), user.getUserPhone(), user.getEmail(), user.getRoles());
    }

    private User mapToEntity(UserDto userDto) {
        return new User(userDto.getUserId(), userDto.getUsername(),
                userDto.getPassword(), userDto.getUserPhone(), userDto.getEmail(), userDto.getRoles());
    }
}
