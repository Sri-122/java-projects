package com.capgemini.sweetmart.dto;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.validation.constraints.*;

import java.util.Set;

    public class UserDto {

        @Positive(message = "{validation.user.id.positive}")
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long userId;

        @NotBlank(message = "{validation.user.name.required}")
        @Size(min = 1, max = 50, message = "{validation.user.name.size}")
        @Pattern(regexp = "^[a-zA-Z]{7,15}$", message = "{validation.username.invalid}")
        private String username;

        @NotBlank(message = "{validation.user.password.required}")
        @Size(min = 6, message = "{validation.user.password.size}")
        @Pattern(regexp = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", message = "{validation.password.invalid}")
        private String password;

        private Long userPhone;

        @NotBlank(message = "{validation.user.email.required}")
        @Email(message = "{validation.user.email.format}")
        private String email;

        @NotEmpty(message = "{validation.user.roles.required}")
        @Size(min=1,max=2,message="{validation.user.roles.size}")
        private Set<@Pattern(regexp="^(?i)(ADMIN|CUSTOMER)$",message="{validation.user.roles.invalid}")String> roles;

        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public Long getUserPhone() {
            return userPhone;
        }

        public void setUserPhone(Long userPhone) {
            this.userPhone = userPhone;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public Set<String> getRoles() {
            return roles;
        }

        public void setRoles(Set<String> roles) {
            this.roles = roles;
        }

        public UserDto(@Positive(message = "{validation.user.id.positive}") Long userId,
                       @NotBlank(message = "{validation.user.name.required}") @Size(min = 1, max = 50, message = "{validation.user.name.size}") String username,
                       @NotBlank(message = "{validation.user.password.required}") @Size(min = 6, message = "{validation.user.password.size}") String password,
                       long userPhone,
                       @NotBlank(message = "{validation.user.email.required}") @Email(message = "{validation.user.email.format}") String email,
                       @NotEmpty(message = "{validation.user.roles.required}") Set<String> roles) {
            super();
            this.userId = userId;
            this.username = username;
            this.password = password;
            this.userPhone = userPhone;
            this.email = email;
            this.roles = roles;
        }
    }


