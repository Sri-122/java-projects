/*package com.capgemini.sweetmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}*/

package com.capgemini.sweetmart;

import com.capgemini.sweetmart.exception.ProductNotFoundException;
import com.capgemini.sweetmart.model.Product;
import com.capgemini.sweetmart.service.ProductServiceImpl;
import com.capgemini.sweetmart.repository.IProductRepository;
import com.capgemini.sweetmart.repository.ICategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
class ProductServiceApplicationTests {

	@Autowired
	private ProductServiceImpl productService;

	@Autowired
	private IProductRepository productRepository;

	@Autowired
	private ICategoryRepository categoryRepository;

	@BeforeEach
	void setUp() {
		// This can be used to set up data or mock beans if needed before each test.
	}

	@Test
	void contextLoads() {
		// Verify that the Spring Boot application context loads successfully
		assertThat(productService).isNotNull();
		assertThat(productRepository).isNotNull();
		assertThat(categoryRepository).isNotNull();
	}

	@Test
	void testProductServiceBean() {
		// Ensure that ProductServiceImpl bean is loaded correctly
		assertThat(productService).isNotNull();
	}

	@Test
	void testProductRepositoryBean() {
		// Ensure that the ProductRepository bean is loaded correctly
		assertThat(productRepository).isNotNull();
	}

	@Test
	void testCategoryRepositoryBean() {
		// Ensure that the CategoryRepository bean is loaded correctly
		assertThat(categoryRepository).isNotNull();
	}

	@Test
	void testApplicationContextLoads() {
		// Verify that the Spring Boot application context is up and running
		assertThat(productService).isNotNull();
	}

	// Example of an integration test that checks if data is being fetched from the database
	@Test
	void testFetchAllProducts() {
		// This assumes you have data already in the database or you could use @DataJpaTest to set up a test environment.
		var products = productService.viewAllProducts();
		assertThat(products).isNotEmpty();
	}

	@Test
	void testViewProductById_ProductNotFound() {
		Integer productId = 999; // Non-existent product ID

		ProductNotFoundException exception = assertThrows(ProductNotFoundException.class, () -> {
			productService.viewProduct(productId);
		});

		assertThat(exception.getMessage()).isEqualTo("Product not found with id: " + productId);
	}
}
