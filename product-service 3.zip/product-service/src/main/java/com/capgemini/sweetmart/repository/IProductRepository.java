package com.capgemini.sweetmart.repository;

import com.capgemini.sweetmart.dto.ProductDTO;
import com.capgemini.sweetmart.exception.ProductNotFoundException;
import com.capgemini.sweetmart.model.Category;
import com.capgemini.sweetmart.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface IProductRepository extends JpaRepository<Product,Integer> {

    List<Product> findByProductId(int productId);

    List<Product> findByCategoryId(int categoryId);

    List<Product> findByCategory(Category category);
}

