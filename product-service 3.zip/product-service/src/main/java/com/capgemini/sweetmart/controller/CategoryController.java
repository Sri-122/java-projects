
package com.capgemini.sweetmart.controller;

import java.util.List;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.sweetmart.dto.CategoryDTO;
import com.capgemini.sweetmart.model.Category;
import com.capgemini.sweetmart.exception.CategoryAlreadyExists;
import com.capgemini.sweetmart.exception.CategoryNotFoundException;
import com.capgemini.sweetmart.service.ICategoryService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/category")
public class CategoryController {

    private static final Logger logger = LoggerFactory.getLogger(CategoryController.class);

    @Autowired
    private ICategoryService categoryService;

    // Get all categories
    @GetMapping("/getAllCategories")
    public ResponseEntity<List<Category>> getAllCategories() {
        logger.info("Request to get all categories received.");

        // Retrieve all categories from the service
        List<Category> categories = categoryService.viewAllCategories();

        // Return the list of Category objects with HTTP status 200 OK
        logger.info("Returning {} categories.", categories.size());
        return new ResponseEntity<>(categories, HttpStatus.OK); // Returns 200 OK with the list of Category entities
    }

    // Get category by ID
    @GetMapping("/getCategoryById/{id}")
    public ResponseEntity<Category> getCategoryById(@PathVariable Integer id) throws CategoryNotFoundException {
        logger.info("Request to get category by ID: {}", id);

        // Try to get the category by ID
        Category category = categoryService.viewCategory(id); // This will throw CategoryNotFoundException if not found

        logger.info("Category with ID {} found: {}", id, category.getName());
        return new ResponseEntity<>(category, HttpStatus.OK);
    }

    // Add a new category
    @PostMapping("/addCategory")
    public ResponseEntity<Category> addCategory(@Valid @RequestBody CategoryDTO categoryDTO) throws CategoryAlreadyExists {
        logger.info("Request to add new category: {}", categoryDTO.getName());

        // Try to add the category
        Category category = categoryService.addCategory(categoryDTO);

        // Return the created category object as the response (success case)
        logger.info("Category '{}' added successfully with ID {}", category.getName(), category.getId());
        return new ResponseEntity<>(category, HttpStatus.CREATED);
    }

    // Update an existing category
    @PutMapping("/updateCategory/{id}")
    public ResponseEntity<Category> updateCategory(@PathVariable Integer id, @Valid @RequestBody CategoryDTO categoryDTO) throws CategoryNotFoundException {
        logger.info("Request to update category with ID: {}", id);

        // Set the ID from the path variable to the categoryDTO object
        categoryDTO.setId(id);

        // Call the service layer to update the category and get the updated category
        Category updatedCategory = categoryService.updateCategory(categoryDTO);

        logger.info("Category with ID {} updated successfully.", id);
        return new ResponseEntity<>(updatedCategory, HttpStatus.OK);
    }

    // Delete category by ID
    @DeleteMapping("/deleteCategory/{id}")
    public ResponseEntity<String> deleteCategory(@PathVariable Integer id) throws CategoryNotFoundException {
        logger.info("Request to delete category with ID: {}", id);

        // Check if the category exists
        Category categoryToDelete = categoryService.viewCategory(id);

        // Proceed with the deletion
        categoryService.removeCategory(id); // This might throw CategoryNotFoundException

        // Return a success message along with the deleted category's ID
        logger.info("Category with ID {} deleted successfully.", id);
        return ResponseEntity.status(HttpStatus.OK)
                .body("Category with ID " + id + " deleted successfully.");
    }

    // Helper method to convert Category to CategoryDTO
    private CategoryDTO convertToCategoryDTO(Category category) {
        return new CategoryDTO(category.getId(), category.getName());
    }
}
