//package com.capgemini.sweetmart.controller;
//
//import com.capgemini.sweetmart.dto.ProductDTO;
//import com.capgemini.sweetmart.exception.CategoryNotFoundException;
//import com.capgemini.sweetmart.exception.ProductNotFoundException;
//import com.capgemini.sweetmart.model.Category;
//import com.capgemini.sweetmart.model.Product;
//import com.capgemini.sweetmart.service.ICategoryService;
//import com.capgemini.sweetmart.service.IProductservice;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//
//import jakarta.validation.Valid;
//import java.util.List;
//
//@RestController
//@RequestMapping("/products")
//public class ProductController {
//    @Autowired
//    private IProductservice productService;
//
//    @Autowired
//    private ICategoryService categoryService;
//
//    // Method to get all products
//    @GetMapping("/getAllProducts")
//    public ResponseEntity<List<Product>> getAllProducts() {
//        List<Product> products = productService.viewAllProducts();
//        return new ResponseEntity<>(products, HttpStatus.OK);
//    }
//
//    // Method to add a new product
//    @PostMapping("/addProduct")
//    public ResponseEntity<Product> addProduct(@Valid @RequestBody ProductDTO productDTO) {
//        Product addedProduct = productService.addProduct(productDTO);
//        return new ResponseEntity<>(addedProduct, HttpStatus.CREATED);
//    }
//
//    // Method to update an existing product
//    @PutMapping("/updateProduct/{id}")
//    public ResponseEntity<Product> updateProduct(@PathVariable Integer id, @Valid @RequestBody ProductDTO productDTO) throws ProductNotFoundException {
//        // Set the Product ID from the path variable
//        productDTO.setProductId(id);
//
//        Product updatedProduct = productService.updateProduct(productDTO);
//        return new ResponseEntity<>(updatedProduct, HttpStatus.OK);
//    }
//
//    // Method to get a product by ID
//    @GetMapping("/getProductsById/{id}")
//    public ResponseEntity<Product> getProductById(@PathVariable Integer id) throws ProductNotFoundException {
//        Product product = productService.viewProduct(id);
//        return new ResponseEntity<>(product, HttpStatus.OK);
//    }
//
//    // Method to get products by category
//    @GetMapping("/getCategoryByName/{cat}")
//    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable String cat) throws CategoryNotFoundException {
//        // Fetch Category by name
//        Category category = categoryService.getCategoryByName(cat); // Assuming you have this method in your service
//
//        // Fetch products by category from productService
//        List<Product> products = productService.viewProductsByCategory(category);
//
//        return new ResponseEntity<>(products, HttpStatus.OK);
//    }
//
//    // Method to remove a product
//    @DeleteMapping("/removeProduct/{id}")
//    public ResponseEntity<Object> removeProduct(@PathVariable Integer id) throws ProductNotFoundException {
//        Product productToDelete = productService.viewProduct(id);  // Assuming viewProduct method retrieves the product by ID
//
//        // Proceed with the removal process
//        productService.removeProduct(id); // This might throw ProductNotFoundException
//
//        // Return success message after deletion
//        return ResponseEntity.status(HttpStatus.OK)
//                .body("Product with ID " + id + " deleted successfully.");
//
//    }
//
//    // Helper method to convert ProductDTO to Product
//    private Product convertToProduct(ProductDTO productDTO) {
//        Product product = new Product();
//        product.setProductId(productDTO.getProductId());
//        product.setName(productDTO.getName());
//        product.setPrice(productDTO.getPrice());
//        product.setQuantity(productDTO.getQuantity());
//        product.setPhotoPath(productDTO.getPhotoPath());
//        product.setAvailable(productDTO.getAvailable());
//        product.setDescription(productDTO.getDescription());
//        return product;
//    }
//}



package com.capgemini.sweetmart.controller;

import com.capgemini.sweetmart.dto.ProductDTO;
import com.capgemini.sweetmart.exception.CategoryNotFoundException;
import com.capgemini.sweetmart.exception.ProductNotFoundException;
import com.capgemini.sweetmart.model.Category;
import com.capgemini.sweetmart.model.Product;
import com.capgemini.sweetmart.service.ICategoryService;
import com.capgemini.sweetmart.service.IProductservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/products")
public class ProductController {

    private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private IProductservice productService;

    @Autowired
    private ICategoryService categoryService;

    // Method to get all products
    @GetMapping("/getAllProducts")
    public ResponseEntity<List<Product>> getAllProducts() {
        logger.info("Entering getAllProducts method to retrieve all products.");

        List<Product> products = productService.viewAllProducts();

        logger.info("Successfully retrieved {} products.", products.size());
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // Method to add a new product
    @PostMapping("/addProduct")
    public ResponseEntity<Product> addProduct(@Valid @RequestBody ProductDTO productDTO) {
        logger.info("Entering addProduct method with product details: {}", productDTO);

        Product addedProduct = productService.addProduct(productDTO);

        logger.info("Product '{}' added successfully with ID {}", addedProduct.getName(), addedProduct.getProductId());
        return new ResponseEntity<>(addedProduct, HttpStatus.CREATED);
    }

    // Method to update an existing product
    @PutMapping("/updateProduct/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Integer id, @Valid @RequestBody ProductDTO productDTO) throws ProductNotFoundException {
        logger.info("Request to update product with ID: {}", id);

        // Set the Product ID from the path variable
        productDTO.setProductId(id);

        Product updatedProduct = productService.updateProduct(productDTO);

        logger.info("Product with ID {} updated successfully: {}", id, updatedProduct.getName());
        return new ResponseEntity<>(updatedProduct, HttpStatus.OK);
    }

    // Method to get a product by ID
    @GetMapping("/getProductsById/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Integer id) throws ProductNotFoundException {
        logger.info("Request to get product by ID: {}", id);

        Product product = productService.viewProduct(id);

        logger.info("Product with ID {} retrieved: {}", id, product.getName());
        return new ResponseEntity<>(product, HttpStatus.OK);
    }

    // Method to get products by category
    @GetMapping("/getCategoryByName/{cat}")
    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable String cat) throws CategoryNotFoundException {
        logger.info("Request to get products by category name: {}", cat);

        // Fetch Category by name
        Category category = categoryService.getCategoryByName(cat);

        // Fetch products by category from productService
        List<Product> products = productService.viewProductsByCategory(category);

        logger.info("Successfully retrieved {} products for category: {}", products.size(), cat);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // Method to remove a product
    @DeleteMapping("/removeProduct/{id}")
    public ResponseEntity<Object> removeProduct(@PathVariable Integer id) throws ProductNotFoundException {
        logger.info("Request to delete product with ID: {}", id);

        Product productToDelete = productService.viewProduct(id);  // Assuming viewProduct method retrieves the product by ID

        // Proceed with the removal process
        productService.removeProduct(id); // This might throw ProductNotFoundException

        logger.info("Product with ID {} deleted successfully.", id);
        return ResponseEntity.status(HttpStatus.OK)
                .body("Product with ID " + id + " deleted successfully.");
    }

    // Helper method to convert ProductDTO to Product
    private Product convertToProduct(ProductDTO productDTO) {
        Product product = new Product();
        product.setProductId(productDTO.getProductId());
        product.setName(productDTO.getName());
        product.setPrice(productDTO.getPrice());
        product.setQuantity(productDTO.getQuantity());
        product.setPhotoPath(productDTO.getPhotoPath());
        product.setAvailable(productDTO.getAvailable());
        product.setDescription(productDTO.getDescription());
        return product;
    }
}
