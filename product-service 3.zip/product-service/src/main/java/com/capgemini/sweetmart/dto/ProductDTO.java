package com.capgemini.sweetmart.dto;

import com.capgemini.sweetmart.model.Category;
import jakarta.validation.constraints.*;


public class ProductDTO {
    //@NotNull(message = "Product ID cannot be null")
    private Integer productId;

    @NotBlank(message = "{NotBlank.ProductDTO.name}")
    @Pattern(regexp = "^[A-Za-z\\s]+$", message = "{validation.product.productName.pattern}")

    private String name;

    @NotBlank(message = "{NotBlank.ProductDTO.photoPath}")
    @Pattern(regexp = "^[A-Za-z\\s]+$", message = "{validation.product.photoPath.pattern}")
    private String photoPath;

    @NotNull(message = "{NotNull.ProductDTO.price}")
    @Positive(message = "{Positive.ProductDTO.price}")
    private Double price;

    @NotNull(message = "{NotBlank.ProductDTO.description}")
    @Size(min = 1, message = "{Size.ProductDTO.description}")
    @Pattern(regexp = "^[A-Za-z\\s]+$", message = "{validation.product.description.pattern}")
    private String description;

    @NotNull(message = "{NotNull.ProductDTO.available}")
    private Boolean available;

    @NotNull(message = "{NotNull.ProductDTO.quantity}")
    @Positive(message = "{Positive.ProductDTO.quantity}")
    private Integer quantity;

    @NotNull(message = "{NotNull.ProductDTO.category}")
    //@Size(min = 1, message = "{Size.ProductDTO.category}")
    private Category category;

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}


