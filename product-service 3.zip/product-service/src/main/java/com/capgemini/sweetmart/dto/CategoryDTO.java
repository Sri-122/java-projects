package com.capgemini.sweetmart.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import org.hibernate.sql.Update;

public class CategoryDTO {

    private Integer id;

    @NotBlank(message = "{NotNull.CategoryDTO.name}")
    @Pattern(regexp = "^[A-Za-z\\s]+$", message = "{validation.category.categoryName.pattern}")
    private String name;

    // Constructors, getters, and setters
    public CategoryDTO() {

    }

    public CategoryDTO(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
