package com.capgemini.sweetmart.service;

import com.capgemini.sweetmart.dto.CategoryDTO;
import com.capgemini.sweetmart.exception.CategoryAlreadyExists;
import com.capgemini.sweetmart.exception.CategoryNotFoundException;
import com.capgemini.sweetmart.model.Category;

import java.util.List;

public interface ICategoryService {
    List<Category> viewAllCategories();

    Category addCategory(CategoryDTO categoryDTO) throws CategoryAlreadyExists;

    Category updateCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException;


    Category viewCategory(Integer id) throws CategoryNotFoundException;

    void removeCategory(Integer id) throws CategoryNotFoundException;

    Category getCategoryByName(String name) throws CategoryNotFoundException;

}


