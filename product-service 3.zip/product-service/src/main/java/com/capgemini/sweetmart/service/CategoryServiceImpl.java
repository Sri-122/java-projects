/*package com.capgemini.sweetmart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.sweetmart.dto.CategoryDTO;
import com.capgemini.sweetmart.model.Category;
import com.capgemini.sweetmart.exception.CategoryAlreadyExists;
import com.capgemini.sweetmart.exception.CategoryNotFoundException;
import com.capgemini.sweetmart.repository.ICategoryRepository;
@Service
public class CategoryServiceImpl implements ICategoryService{
    @Autowired
    private ICategoryRepository categoryRepository;

    @Override
    public List<Category> viewAllCategories() {
        return categoryRepository.findAll();
    }

    @Override
    public Category addCategory(CategoryDTO categoryDTO) throws CategoryAlreadyExists{
        Optional<Category> existingCategory = categoryRepository.findByName(categoryDTO.getName());

        // If category already exists, throw CategoryAlreadyExists exception
        if (existingCategory.isPresent()) {
            throw new CategoryAlreadyExists("Category with name " + categoryDTO.getName() + " already exists.");
        }

        // If category doesn't exist, proceed to save the new category
        Category category = convertToCategory(categoryDTO);
        return categoryRepository.save(category);
    }

    @Override
    public Category updateCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException{
        Optional<Category> existingCategory = categoryRepository.findById(categoryDTO.getId());
        if (existingCategory.isPresent()) {
            Category category = convertToCategory(categoryDTO);
            return categoryRepository.save(category);
        } else {
            throw new RuntimeException("Category not found with ID: " + categoryDTO.getId());
        }
    }

    @Override
    public Category viewCategory(Integer id) throws CategoryNotFoundException {
        return categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found with ID: " + id));
    }

    @Override
    public void removeCategory(Integer id) throws CategoryNotFoundException{
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found with ID: " + id));
        categoryRepository.delete(category);
    }

    public Category getCategoryByName(String name) throws CategoryNotFoundException{
        return categoryRepository.findByName(name)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with name: " + name));
    }

    // Helper method to convert CategoryDTO to Category
    private Category convertToCategory(CategoryDTO categoryDTO) {
        return new Category(categoryDTO.getId(), categoryDTO.getName());
    }
}*/


package com.capgemini.sweetmart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capgemini.sweetmart.dto.CategoryDTO;
import com.capgemini.sweetmart.model.Category;
import com.capgemini.sweetmart.exception.CategoryAlreadyExists;
import com.capgemini.sweetmart.exception.CategoryNotFoundException;
import com.capgemini.sweetmart.repository.ICategoryRepository;

@Service
public class CategoryServiceImpl implements ICategoryService {

    private static final Logger logger = LoggerFactory.getLogger(CategoryServiceImpl.class);

    @Autowired
    private ICategoryRepository categoryRepository;

    @Override
    public List<Category> viewAllCategories() {
        logger.info("Fetching all categories.");
        List<Category> categories = categoryRepository.findAll();
        logger.info("Found {} categories.", categories.size());
        return categories;
    }

    @Override
    public Category addCategory(CategoryDTO categoryDTO) throws CategoryAlreadyExists {
        logger.info("Attempting to add category: {}", categoryDTO.getName());

        Optional<Category> existingCategory = categoryRepository.findByName(categoryDTO.getName());

        // If category already exists, throw CategoryAlreadyExists exception
        if (existingCategory.isPresent()) {
            logger.error("Category with name {} already exists.", categoryDTO.getName());
            throw new CategoryAlreadyExists("Category with name " + categoryDTO.getName() + " already exists.");
        }

        // If category doesn't exist, proceed to save the new category
        Category category = convertToCategory(categoryDTO);
        Category savedCategory = categoryRepository.save(category);
        logger.info("Category '{}' added successfully with ID: {}", savedCategory.getName(), savedCategory.getId());
        return savedCategory;
    }

    @Override
    public Category updateCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException {
        logger.info("Attempting to update category with ID: {}", categoryDTO.getId());

        Optional<Category> existingCategory = categoryRepository.findById(categoryDTO.getId());
        if (existingCategory.isPresent()) {
            Category category = convertToCategory(categoryDTO);
            Category updatedCategory = categoryRepository.save(category);
            logger.info("Category with ID {} updated successfully.", updatedCategory.getId());
            return updatedCategory;
        } else {
            logger.error("Category with ID {} not found for update.", categoryDTO.getId());
            throw new CategoryNotFoundException("Category not found with ID: " + categoryDTO.getId());
        }
    }

    @Override
    public Category viewCategory(Integer id) throws CategoryNotFoundException {
        logger.info("Fetching category with ID: {}", id);
        return categoryRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Category with ID {} not found.", id);
                    return new CategoryNotFoundException("Category not found with ID: " + id);
                });
    }

    @Override
    public void removeCategory(Integer id) throws CategoryNotFoundException {
        logger.info("Attempting to remove category with ID: {}", id);
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Category with ID {} not found for removal.", id);
                    return new CategoryNotFoundException("Category not found with ID: " + id);
                });
        categoryRepository.delete(category);
        logger.info("Category with ID {} removed successfully.", id);
    }

    public Category getCategoryByName(String name) throws CategoryNotFoundException {
        logger.info("Fetching category with name: {}", name);
        return categoryRepository.findByName(name)
                .orElseThrow(() -> {
                    logger.error("Category with name {} not found.", name);
                    return new CategoryNotFoundException("Category not found with name: " + name);
                });
    }

    // Helper method to convert CategoryDTO to Category
    private Category convertToCategory(CategoryDTO categoryDTO) {
        return new Category(categoryDTO.getId(), categoryDTO.getName());
    }
}

