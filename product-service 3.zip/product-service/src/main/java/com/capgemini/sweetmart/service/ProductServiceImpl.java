package com.capgemini.sweetmart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capgemini.sweetmart.dto.ProductDTO;
import com.capgemini.sweetmart.model.Category;
import com.capgemini.sweetmart.model.Product;
import com.capgemini.sweetmart.exception.ProductNotFoundException;
import com.capgemini.sweetmart.repository.ICategoryRepository;
import com.capgemini.sweetmart.repository.IProductRepository;

@Service
public class ProductServiceImpl  implements IProductservice {

    private static final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

    @Autowired
    private IProductRepository productRepository;

    @Autowired
    private ICategoryRepository categoryRepository;

    @Override
    public List<Product> viewAllProducts() {
        logger.info("Fetching all products.");
        List<Product> products = productRepository.findAll();
        logger.info("Found {} products.", products.size());
        return products;
    }

    @Override
    public Product addProduct(ProductDTO productDTO) {
        logger.info("Adding new product: {}", productDTO.getName());

        // Fetch the existing category based on the Category DTO passed from ProductDTO
        Category category = categoryRepository.findById(productDTO.getCategory().getId())
                .orElseThrow(() -> new RuntimeException("Category not found"));
        logger.debug("Category found: {}", category.getName());

        // Create and set the product based on the ProductDTO
        Product product = convertToProduct(productDTO);
        product.setCategory(category); // Set the fetched category to the product

        // Save the product
        Product savedProduct = productRepository.save(product);
        logger.info("Product '{}' added successfully with ID: {}", savedProduct.getName(), savedProduct.getProductId());

        return savedProduct;
    }

    @Override
    public Product updateProduct(ProductDTO productDTO) throws ProductNotFoundException {
        Integer productId = productDTO.getProductId();
        logger.info("Updating product with ID: {}", productId);

        if (!productRepository.existsById(productId)) {
            logger.error("Product with ID {} not found for update.", productId);
            throw new ProductNotFoundException("Product not found with id: " + productId);
        }

        // Find the existing product
        Product existingProduct = productRepository.findById(productId).get();

        // Update product properties based on ProductDTO
        existingProduct.setName(productDTO.getName());
        existingProduct.setPrice(productDTO.getPrice());
        existingProduct.setQuantity(productDTO.getQuantity());
        existingProduct.setPhotoPath(productDTO.getPhotoPath());
        existingProduct.setAvailable(productDTO.getAvailable());
        existingProduct.setDescription(productDTO.getDescription());

        // Fetch and set the category (Category is passed via ProductDTO)
        Category category = categoryRepository.findById(productDTO.getCategory().getId())
                .orElseThrow(() -> new RuntimeException("Category not found"));
        existingProduct.setCategory(category);

        // Save and return updated product
        Product updatedProduct = productRepository.save(existingProduct);
        logger.info("Product with ID {} updated successfully.", updatedProduct.getProductId());

        return updatedProduct;
    }

    @Override
    public Product viewProduct(Integer id) throws ProductNotFoundException {
        logger.info("Fetching product with ID: {}", id);
        return productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + id));
    }

    @Override
    public List<Product> viewProductsByCategory(Category category) {
        logger.info("Fetching products for category: {}", category.getName());
        List<Product> products = productRepository.findByCategory(category);
        logger.info("Found {} products for category: {}", products.size(), category.getName());
        return products;
    }

    @Override
    public Product removeProduct(Integer id) throws ProductNotFoundException {
        logger.info("Removing product with ID: {}", id);

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + id));

        productRepository.delete(product);
        logger.info("Product with ID {} removed successfully.", id);
        return product;
    }

    private Product convertToProduct(ProductDTO productDTO) {
        Product product = new Product();
        product.setProductId(productDTO.getProductId());
        product.setName(productDTO.getName());
        product.setPrice(productDTO.getPrice());
        product.setQuantity(productDTO.getQuantity());
        product.setDescription(productDTO.getDescription());
        product.setAvailable(productDTO.getAvailable());
        product.setPhotoPath(productDTO.getPhotoPath());
        return product;
    }
}

