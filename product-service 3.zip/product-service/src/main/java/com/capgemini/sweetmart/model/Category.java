package com.capgemini.sweetmart.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Category {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "category_id") // Match the database column name
        private Integer id;


    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.LAZY,mappedBy = "category")
    private List<Product> product;

        @Column(name = "category_name", unique = true) // Match the database column name
        private String name;


        // Default constructor
        public Category() {}

        // Constructor with name
        public Category(String name) {
            this.name = name;
        }

        // Constructor with id and name
        public Category(Integer id, String name) {
            this.id = id;
            this.name = name;
        }

        // Getters and setters
        public Integer getId() {

            return id;
        }

        public void setId(Integer id) {

            this.id = id;
        }

        public String getName() {

            return name;
        }

        public void setName(String name) {

            this.name = name;
        }
    }