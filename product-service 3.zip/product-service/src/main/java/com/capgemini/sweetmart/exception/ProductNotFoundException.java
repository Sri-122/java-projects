package com.capgemini.sweetmart.exception;

public class ProductNotFoundException extends Exception{
    public ProductNotFoundException(String Message) {
        super(Message);
    }
    public ProductNotFoundException() {
    }
}

