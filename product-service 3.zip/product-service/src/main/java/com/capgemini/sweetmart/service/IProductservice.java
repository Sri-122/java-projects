package com.capgemini.sweetmart.service;

import com.capgemini.sweetmart.dto.ProductDTO;
import com.capgemini.sweetmart.exception.ProductNotFoundException;
import com.capgemini.sweetmart.model.Category;
import com.capgemini.sweetmart.model.Product;

import java.util.List;

public interface IProductservice {
    List<Product> viewAllProducts();

    Product addProduct(ProductDTO productDTO);

    Product updateProduct(ProductDTO productDTO) throws ProductNotFoundException;

    Product viewProduct(Integer id) throws ProductNotFoundException;

    List<Product> viewProductsByCategory(Category category);

    Product removeProduct(Integer id) throws ProductNotFoundException;
}





