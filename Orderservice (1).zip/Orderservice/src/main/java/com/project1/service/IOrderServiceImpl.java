package com.project1.service;

import com.project1.client.CartServiceClient;
import com.project1.dto.OrderDTO;
import com.project1.entity.Order;
import com.project1.exception.OrderAlreadyExistsException;
import com.project1.exception.OrderNotFoundException;
import com.project1.repository.IOrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class IOrderServiceImpl implements IOrderService {

    private static final Logger logger = LoggerFactory.getLogger(IOrderServiceImpl.class);

    @Autowired
    private IOrderRepository orderRepository;

    @Autowired
    private CartServiceClient cartServiceClient;

    // Convert Order entity to OrderDTO
    private OrderDTO convertToDTO(Order order) {
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(order.getOrderId());
        orderDTO.setCartId(order.getCartId());
        orderDTO.setUserId(order.getUserId());
        orderDTO.setOrderStatus(order.getOrderStatus());
        orderDTO.setOrderDate(order.getOrderDate());
        orderDTO.setAddress(order.getAddress());
        orderDTO.setTotalCost(cartServiceClient.showCartById(order.getCartId()).getTotal());
        return orderDTO;
    }

    // Convert OrderDTO to Order entity
    private Order convertToEntity(OrderDTO orderDTO) {
        Order order = new Order();
        order.setUserId(orderDTO.getUserId());
        order.setCartId(orderDTO.getCartId());
        order.setOrderStatus(orderDTO.getOrderStatus());
        order.setOrderDate(orderDTO.getOrderDate());
        order.setAddress(orderDTO.getAddress());
        order.setTotalCost(cartServiceClient.showCartById(orderDTO.getCartId()).getTotal());
        return order;
    }

//    @Override
//    public OrderDTO addOrder(OrderDTO orderDTO) {
//        logger.info("Adding a new order: {}", orderDTO);
//        Optional<Order> existingOrder = orderRepository.findById(orderDTO.getOrderId());
//
//        if (existingOrder.isPresent()) {
//            logger.warn("Order already exists with ID: {}", orderDTO.getOrderId());
//            throw new OrderAlreadyExistsException("An order with ID " + orderDTO.getOrderId() + " already exists.");
//        }
//
//        Order order = convertToEntity(orderDTO);
//        logger.debug("Order converted from DTO: {}", order);
//
//        if (order.getCartId() != null) {
//            try {
//                order.setTotalCost(cartServiceClient.showCartById(order.getCartId()).getTotal());
//                logger.info("Fetched cart total cost for cart ID: {}", order.getCartId());
//            } catch (Exception e) {
//                logger.error("Error fetching cart details: {}", e.getMessage());
//                order.setTotalCost(0.0);
//            }
//        } else {
//            order.setTotalCost(0.0);
//        }
//
//        Order savedOrder = orderRepository.save(order);
//        logger.info("Order saved successfully with ID: {}", savedOrder.getOrderId());
//        return convertToDTO(savedOrder);
//    }
@Override
public OrderDTO addOrder(OrderDTO orderDTO) {
    logger.info("Adding a new order: {}", orderDTO);

    // Ensure ID is null so Hibernate generates a new one
    Order order = convertToEntity(orderDTO);
    order.setOrderId(null);

    logger.debug("Converted Order before saving: {}", order);

    if (order.getCartId() != null) {
        try {
            order.setTotalCost(cartServiceClient.showCartById(order.getCartId()).getTotal());
            logger.info("Fetched cart total cost for cart ID: {}", order.getCartId());
        } catch (Exception e) {
            logger.error("Error fetching cart details: {}", e.getMessage());
            order.setTotalCost(0.0);
        }
    } else {
        order.setTotalCost(0.0);
    }

    Order savedOrder = orderRepository.save(order);
    logger.info("Order saved successfully with ID: {}", savedOrder.getOrderId());

    return convertToDTO(savedOrder);
}



    @Override
    public OrderDTO updateOrder(Long orderId, OrderDTO orderDTO) {
        logger.info("Updating order with ID: {}", orderId);
        Optional<Order> orderOpt = orderRepository.findById(orderId);

        if (orderOpt.isEmpty()) {
            logger.warn("Order not found with ID: {}", orderId);
            throw new OrderNotFoundException("Order with ID " + orderId + " not found.");
        }

        Order order = orderOpt.get();
        order.setUserId(orderDTO.getUserId());
        order.setOrderStatus(orderDTO.getOrderStatus());
        order.setOrderDate(orderDTO.getOrderDate());
        order.setAddress(orderDTO.getAddress());
        Order updatedOrder = orderRepository.save(order);
        logger.info("Order updated successfully: {}", updatedOrder);
        return convertToDTO(updatedOrder);
    }

    @Override
    public OrderDTO viewOrder(Long orderId) {
        logger.info("Fetching order with ID: {}", orderId);
        Optional<Order> orderOpt = orderRepository.findById(orderId);

        if (orderOpt.isEmpty()) {
            logger.warn("Order not found with ID: {}", orderId);
            throw new OrderNotFoundException("Order with ID " + orderId + " not found.");
        }

        return convertToDTO(orderOpt.get());
    }

    @Override
    public List<OrderDTO> viewOrdersByUserId(Long userId) {
        logger.info("Fetching orders for user ID: {}", userId);
        List<Order> orders = orderRepository.findByUserId(userId);
        return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<OrderDTO> viewOrdersByAddress(String address) {
        logger.info("Fetching orders for address: {}", address);
        List<Order> orders = orderRepository.findByAddress(address);
        return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<OrderDTO> viewOrdersByDate(LocalDate orderDate) {
        logger.info("Fetching orders for date: {}", orderDate);
        List<Order> orders = orderRepository.findByOrderDate(orderDate);
        return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public Order removeOrder(Long id) {
        logger.info("Removing order with ID: {}", id);
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> {
                    logger.warn("Order not found with ID: {}", id);
                    return new OrderNotFoundException("Product not found with id: " + id);
                });
        orderRepository.delete(order);
        logger.info("Order deleted successfully with ID: {}", id);
        return order;
    }
}
