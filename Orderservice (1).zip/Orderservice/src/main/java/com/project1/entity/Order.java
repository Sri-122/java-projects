package com.project1.entity;

import jakarta.persistence.*;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //@Column(name = "order_id")
    private Long orderId; 

    @Column(name = "user_id")
    private Long userId;
    
    @Column(name = "order_status")
    private String orderStatus;  

    @Column(name = "order_date")
    private LocalDate orderDate; 

    @Column(name = "address")
    private String address;

	@Column(name= "cartId")
	private Integer cartId;
    
//    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<OrderLine> orderLines;

	@Column(name="totalCost")
	private Double totalCost;


	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public Double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

	public Order(Long orderId, Long userId, String orderStatus, LocalDate orderDate, String address, Integer cartId, Double totalCost) {
		this.orderId = orderId;
		this.userId = userId;
		this.orderStatus = orderStatus;
		this.orderDate = orderDate;
		this.address = address;
		this.cartId = cartId;
		this.totalCost = totalCost;
	}

	public Order() {
    	this.orderDate=LocalDate.now();
    }


}
