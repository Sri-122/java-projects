package com.project1.dto;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Min;


public class OrderDTO {


    private Long orderId;

    @NotNull(message = "{order.userId.required}")
    @Size(min = 3, max = 50, message = "{order.userId.size}")
    private Long userId;

    @NotNull(message = "{order.orderStatus.required}")
    @Size(min = 3, max = 20, message = "{order.orderStatus.size}")
    private String orderStatus;

    @NotNull(message = "{order.orderDate.required}")
    private LocalDate orderDate;

    @NotNull(message = "{order.location.required}")
    @Size(min = 1, max = 255, message = "{order.location.size}")
    private String address;

    @NotNull(message = "Cart ID is required")
    private Integer cartId;


    private Double totalCost;

    // Default constructor
    public OrderDTO() {
    	this.orderDate=LocalDate.now();
    	
    }

    // Constructor with parameters


    public OrderDTO(Long orderId, Long userId, String orderStatus, LocalDate orderDate, String address, Integer cartId, Double totalCost) {
        this.orderId = orderId;
        this.userId = userId;
        this.orderStatus = orderStatus;
        this.orderDate = orderDate;
        this.address = address;
        this.cartId = cartId;
        this.totalCost = totalCost;
    }

    // Getters and Setters
    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }
}
