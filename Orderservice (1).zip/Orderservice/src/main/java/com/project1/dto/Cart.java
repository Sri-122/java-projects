package com.project1.dto;
import java.util.List;
public class Cart {

    private Integer cartId;
    private int userId;
    private Integer productCount;
    private Double total;
    private List<Integer> productId;

    public Cart() {
        super();
    }

    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Integer getProductCount() {
        return productCount;
    }

    public void setProductCount(Integer productCount) {
        this.productCount = productCount;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public List<Integer> getProductId() {
        return productId;
    }

    public void setProductId(List<Integer> productId) {
        this.productId = productId;
    }

    public Cart(Integer cartId, int userId, Integer productCount, Double total, List<Integer> productId) {
        this.cartId = cartId;
        this.userId = userId;
        this.productCount = productCount;
        this.total = total;
        this.productId = productId;
    }
}