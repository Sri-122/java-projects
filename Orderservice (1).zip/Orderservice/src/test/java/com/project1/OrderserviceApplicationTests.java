package com.project1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
//class OrderserviceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.project1.client.CartServiceClient;
import com.project1.dto.OrderDTO;
import com.project1.entity.Order;
import com.project1.exception.OrderAlreadyExistsException;
import com.project1.exception.OrderNotFoundException;
import com.project1.repository.IOrderRepository;
import com.project1.service.IOrderServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class IOrderServiceImplTest {

	@Mock
	private IOrderRepository orderRepository;

	@Mock
	private CartServiceClient cartServiceClient;

	@InjectMocks
	private IOrderServiceImpl orderService;

	private Order order;
	private OrderDTO orderDTO;

	@BeforeEach
	void setUp() {
		order = new Order();
		order.setOrderId(1L);
		order.setUserId(101L);
		order.setOrderStatus("PENDING");
		order.setOrderDate(LocalDate.now());
		order.setAddress("123 Street, City");

		orderDTO = new OrderDTO();
		orderDTO.setOrderId(1L);
		orderDTO.setUserId(101L);
		orderDTO.setOrderStatus("PENDING");
		orderDTO.setOrderDate(LocalDate.now());
		orderDTO.setAddress("123 Street, City");
	}

	@Test
	void testAddOrder_Success() {
		when(orderRepository.findById(orderDTO.getOrderId())).thenReturn(Optional.empty());
		when(orderRepository.save(any(Order.class))).thenReturn(order);

		OrderDTO savedOrder = orderService.addOrder(orderDTO);

		assertNotNull(savedOrder);
		assertEquals(orderDTO.getUserId(), savedOrder.getUserId());
	}

	@Test
	void testAddOrder_OrderAlreadyExists() {
		when(orderRepository.findById(orderDTO.getOrderId())).thenReturn(Optional.of(order));
		assertThrows(OrderAlreadyExistsException.class, () -> orderService.addOrder(orderDTO));
	}

	@Test
	void testUpdateOrder_Success() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.of(order));
		when(orderRepository.save(any(Order.class))).thenReturn(order);

		OrderDTO updatedOrder = orderService.updateOrder(order.getOrderId(), orderDTO);
		assertNotNull(updatedOrder);
		assertEquals(orderDTO.getOrderStatus(), updatedOrder.getOrderStatus());
	}

	@Test
	void testUpdateOrder_NotFound() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.empty());
		assertThrows(OrderNotFoundException.class, () -> orderService.updateOrder(order.getOrderId(), orderDTO));
	}

	@Test
	void testViewOrder_Success() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.of(order));
		OrderDTO foundOrder = orderService.viewOrder(order.getOrderId());
		assertNotNull(foundOrder);
		assertEquals(order.getOrderId(), foundOrder.getOrderId());
	}

	@Test
	void testViewOrder_NotFound() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.empty());
		assertThrows(OrderNotFoundException.class, () -> orderService.viewOrder(order.getOrderId()));
	}

	@Test
	void testViewOrdersByUserId() {
		when(orderRepository.findByUserId(order.getUserId())).thenReturn(List.of(order));
		List<OrderDTO> orders = orderService.viewOrdersByUserId(order.getUserId());
		assertFalse(orders.isEmpty());
	}

	@Test
	void testViewOrdersByAddress() {
		when(orderRepository.findByAddress(order.getAddress())).thenReturn(List.of(order));
		List<OrderDTO> orders = orderService.viewOrdersByAddress(order.getAddress());
		assertFalse(orders.isEmpty());
	}

	@Test
	void testViewOrdersByDate() {
		when(orderRepository.findByOrderDate(order.getOrderDate())).thenReturn(List.of(order));
		List<OrderDTO> orders = orderService.viewOrdersByDate(order.getOrderDate());
		assertFalse(orders.isEmpty());
	}

	@Test
	void testRemoveOrder_Success() {
		when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.of(order));
		doNothing().when(orderRepository).delete(order);

		Order deletedOrder = orderService.removeOrder(order.getOrderId());
		assertNotNull(deletedOrder);
	}

}
